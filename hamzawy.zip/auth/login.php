<?php

include "../connect.php";


$email          = filterRequest('email');
$password       = filterRequest('password');


$stmt = $connect->prepare("SELECT * FROM users WHERE users_email = ? AND users_password = ? " );

$stmt->execute(array($email,$password));

$count = $stmt->rowCount();


if($count > 0){
    echo json_encode(array("status" => "Sign in successfully"));
}else{

    echo json_encode(array("status" => "Sign in failed"));

}



?>