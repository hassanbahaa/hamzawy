<?php

// Here the oprations that i'm gonna use is > insert & select <

include "connect.php";

// add request without image


    // $stmt = $connect->prepare("INSERT INTO `notes` (`notes_title`, `notes_content`, `notes_users`) 
    // VALUES (?,?,?)");

    // Here the oprations that i'm gonna use is > insert & select <

getAllData("users","1=1");



?>


